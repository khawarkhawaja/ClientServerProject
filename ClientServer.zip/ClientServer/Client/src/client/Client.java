/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author pc
 */
public class Client {

    static JTextArea conversation;
    static JTextField typeMessage;
    static JButton sendMessage;

    public Client() {
        JFrame f = new JFrame("Client");
        //set size and location of frame
        f.setSize(300, 500);
        f.setLocation(100, 150);
        //make sure it quits when x is clicked
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //set look and feel
        f.setDefaultLookAndFeelDecorated(true);
        JLabel labelM = new JLabel("Enter Text Here For Server");
        labelM.setBounds(50, 50, 200, 30);
        typeMessage = new JTextField();
        //set size of the text box
        typeMessage.setBounds(50, 100, 200, 30);

        sendMessage = new JButton("Send");
        sendMessage.setSize(40, 60);
        sendMessage.setBounds(50, 150, 200, 30);

        conversation = new JTextArea();
        conversation.setSize(100, 200);
        conversation.setBounds(50, 190, 200, 200);
        //add elements to the frame
        f.add(labelM);
        f.add(typeMessage);
        f.add(sendMessage);
        f.add(conversation);
        f.setLayout(null);
        f.setVisible(true);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        new Client();

        Socket sock = new Socket("127.0.0.1", 3000);
        BufferedReader keyRead = new BufferedReader(new InputStreamReader(System.in));
        OutputStream ostream = sock.getOutputStream();
        PrintWriter pwrite = new PrintWriter(ostream, true);
        InputStream istream = sock.getInputStream();
        BufferedReader receiveRead = new BufferedReader(new InputStreamReader(istream));
        System.out.println("Start the chitchat, type and press Enter key");
        String receiveMessage;
        sendMessage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pwrite.println(typeMessage.getText().toString());
                pwrite.flush();
            }
        });
        while (true) {

            if ((receiveMessage = receiveRead.readLine()) != null) //receive from server
            {
                String oldText = conversation.getText().toString();
                conversation.setText(receiveMessage.toString() + '\n' + oldText);
            }
        }

    }

}
